---
name: "\U0001F6AB 404 Not Found"
about: Please check our Wiki, or visit our Discord server for help with this issue

---

Please do not open issues regarding 404 not found errors.

Information on fixing this issue can be found [on our Wiki](https://github.com/NamelessMC/Nameless/wiki/FAQs#im-getting-a-404-not-found-error-whilst-trying-to-install-namelessmc-on-apache), and if you're still experiencing issues please join our [Discord](https://discord.gg/nameless) for further guidance.
