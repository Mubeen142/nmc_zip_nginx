<?php
declare(strict_types = 1);

namespace App\DataTransferObjects\Admin\Pages\Edit;

class Edit
{
    /**
     * @var int
     */
    private $id;

    /**
     * @var string
     */
    private $title;

    /**
     * @var string
     */
    private $content;

    /**
     * @var string
     */
    private $url;

    /**
     * @param int $id
     *
     * @return Edit
     */
    public function setId(int $id): Edit
    {
        $this->id = $id;

        return $this;
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @param string $title
     *
     * @return Edit
     */
    public function setTitle(string $title): Edit
    {
        $this->title = $title;

        return $this;
    }

    /**
     * @return string
     */
    public function getTitle(): string
    {
        return $this->title;
    }

    /**
     * @param string $content
     *
     * @return Edit
     */
    public function setContent(string $content): Edit
    {
        $this->content = $content;

        return $this;
    }

    /**
     * @return string
     */
    public function getContent(): string
    {
        return $this->content;
    }

    /**
     * @param string $url
     *
     * @return Edit
     */
    public function setUrl(string $url): Edit
    {
        $this->url = $url;

        return $this;
    }

    /**
     * @return string
     */
    public function getUrl(): string
    {
        return $this->url;
    }
}
