<?php
declare(strict_types = 1);

namespace App\Events\Auth;

class RegistrationFailedEvent
{
    public function __construct()
    {
    }
}
