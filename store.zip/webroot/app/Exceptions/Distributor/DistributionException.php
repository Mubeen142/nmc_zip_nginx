<?php
declare(strict_types = 1);

namespace App\Exceptions\Distributor;

use App\Exceptions\RuntimeException;

class DistributionException extends RuntimeException
{
    //
}
