<?php
declare(strict_types = 1);

namespace App\Exceptions\Media;

use App\Exceptions\DomainException;

class ImageException extends DomainException
{
    //
}
