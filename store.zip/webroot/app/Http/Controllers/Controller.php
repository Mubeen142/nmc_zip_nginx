<?php
declare(strict_types = 1);

namespace App\Http\Controllers;

use Illuminate\Routing\Controller as BaseController;

/**
 * Class Controller
 * Parent controller for all application controllers. Here you can put some additional functionality
 * for convenience.
 */
class Controller extends BaseController
{
    //
}
